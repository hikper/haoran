import os

os.system('python SpyLibForIsbn.py')

os.system('python UseIsbnForId.py')

os.system('python IdToXlsx.py')

os.system('bookList.xlsx')